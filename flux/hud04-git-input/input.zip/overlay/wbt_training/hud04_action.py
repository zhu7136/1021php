"""Candidate 29-action/31-physical-PR-joint target term. Not registered for training.

No SDK, robot networking, or AB conversion. Runtime validation still required.
"""
from __future__ import annotations

import torch
from wbt_training.config_values.hud04_robot import (
    POLICY_JOINT_NAMES, HEAD_JOINT_NAMES, default_position,
    policy_action_scales, resolve_policy_indices,
)


class HuD04PositionTargetCore:
    def __init__(self, cfg, env):
        self.cfg = cfg
        self.env = env
        if env.robot_config.control.control_mode != "implicit_position_target":
            raise ValueError("HuD04 target term requires implicit_position_target")
        if not callable(getattr(env.simulator, "apply_position_targets_at_dof", None)):
            raise ValueError("Simulator does not support position targets")
        names = tuple(env.robot_config.dof_names)
        indices = resolve_policy_indices(names)
        if env.num_dof != 31:
            raise ValueError("HuD04 reference requires 31 physical PR joints")
        self._indices = torch.tensor(indices, dtype=torch.long, device=env.device)
        self._head_indices = [names.index(n) for n in HEAD_JOINT_NAMES]
        self._raw_actions = torch.zeros((env.num_envs, 29), device=env.device)
        self._processed_actions = torch.zeros_like(self._raw_actions)
        self.action_scales = torch.tensor(policy_action_scales(), device=env.device)
        self._policy_defaults = torch.tensor([default_position(n) for n in POLICY_JOINT_NAMES], device=env.device)
        defaults = torch.tensor([default_position(n) for n in names], device=env.device)
        self._full_defaults = defaults.expand(env.num_envs, -1).clone()
        self._applied_position_targets = self._full_defaults.clone()
        # This is deliberately 29-dim. Full exporter compatibility is not yet validated.
        env.action_scales = self.action_scales

    @property
    def action_dim(self):
        return 29

    @property
    def raw_actions(self):
        return self._raw_actions

    @property
    def processed_actions(self):
        return self._processed_actions

    def process_actions(self, actions):
        if tuple(actions.shape) != (self.env.num_envs, 29):
            raise ValueError("Expected [num_envs, 29] policy actions")
        if not torch.isfinite(actions).all():
            raise ValueError("Policy actions must be finite")
        self._raw_actions.copy_(actions)
        control = self.env.robot_config.control
        if control.clip_actions:
            limit = float(control.action_clip_value)
            if not 0 < limit < float('inf'):
                raise ValueError("Action clip limit must be finite and positive")
            actions = torch.clamp(actions, -limit, limit)
        self._processed_actions.copy_(self._policy_defaults + actions * self.action_scales)
        self._applied_position_targets.copy_(self._full_defaults)
        self._applied_position_targets[:, self._indices] = self._processed_actions
        self._applied_position_targets[:, self._head_indices] = 0.

    def apply_actions(self):
        self.env.simulator.apply_position_targets_at_dof(self._applied_position_targets)

    def reset(self, env_ids=None):
        if env_ids is None:
            env_ids = slice(None)
        self._raw_actions[env_ids] = 0.
        self._processed_actions[env_ids] = self._policy_defaults
        self._applied_position_targets[env_ids] = self._full_defaults[env_ids]