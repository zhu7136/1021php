"""HuD04 manager adapter; real simulator validation is still required."""
from holosoma.envs.wbt.wbt_manager import WholeBodyTrackingManager
from wbt_training.hud04_env_core import HuD04AssetLayoutMixin


class HuD04WholeBodyTrackingManager(HuD04AssetLayoutMixin, WholeBodyTrackingManager):
    pass