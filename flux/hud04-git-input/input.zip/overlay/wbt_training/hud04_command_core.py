"""CPU-testable lifecycle mixin; physics is supplied by Holosoma, not here."""
import torch
from wbt_training.hud04_state import HuD04StateLayout
from wbt_training.config_values.hud04_robot import ANCHOR_BODY_NAME, TRACKED_BODY_NAMES


class HuD04CommandMixin:
    def setup(self):
        names = tuple(self._env.simulator.dof_names)
        if names != tuple(self._env.robot_config.dof_names):
            raise ValueError('Simulator and configured joint orders differ')
        self._hud04_layout = HuD04StateLayout(names)
        bodies = tuple(self._env.simulator._body_list)
        if not bodies or bodies[0] != 'base_link':
            raise ValueError('HuD04 root body must be base_link at body index zero')
        if not set(TRACKED_BODY_NAMES).issubset(bodies):
            raise ValueError('HuD04 tracking bodies missing from simulator')
        if tuple(self.motion_cfg.body_names_to_track) != TRACKED_BODY_NAMES or tuple(self.motion_cfg.body_name_ref) != (ANCHOR_BODY_NAME,):
            raise ValueError('Unexpected HuD04 tracking bodies/anchor')
        # Uses the genuine parent loader. Files must already have 31 named joints;
        # no global loader monkeypatching or automatic file conversion is done.
        super().setup()
        self._hud04_layout._check(self.joint_pos, 31)
        self._hud04_layout._check(self.joint_vel, 31)

    @property
    def command(self):
        # Leave parent joint_pos/joint_vel at 31 for reset and metrics. Only the
        # policy reference observation is reduced to 29+29, instead of 31+31.
        layout = self._hud04_layout
        return torch.cat((layout.policy_state(self.joint_pos), layout.policy_state(self.joint_vel)), dim=-1)

    def reset(self, env_ids):
        ids = self._ensure_index_tensor(env_ids)
        if ids.numel() == 0:
            return
        super().reset(ids)
        # Upstream writes reset buffers after pose noise and limits; BaseTask
        # later refreshes these into physics. Do not clear unselected envs.
        sim = self._env.simulator
        q, dq = self._hud04_layout.enforce_head_hold(sim.dof_pos[ids], sim.dof_vel[ids])
        sim.dof_pos[ids], sim.dof_vel[ids] = q, dq