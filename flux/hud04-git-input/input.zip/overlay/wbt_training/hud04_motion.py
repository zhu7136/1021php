"""Explicit Holosoma schema conversion for already-retargeted HuD04 motion.

Adds two zero head states and reorders joint columns only. Never converts G1
geometry, renames bodies, or establishes dynamic feasibility. Not auto-enabled.
"""
from __future__ import annotations
import numpy as np
from wbt_training.config_values.hud04_robot import (
    POLICY_JOINT_NAMES, SDK_JOINT_NAMES, resolve_policy_indices, TRACKED_BODY_NAMES,
)


def expand_hud04_motion(data, physical_names=SDK_JOINT_NAMES):
    """Return copied Holosoma arrays with root-prefix + 31 joint columns.

    Caller must validate the motion's HuD04 provenance separately. Requiring
    HuD04 body names is a schema guard, not proof of correct retargeting.
    """
    names = tuple(physical_names)
    policy_indices = resolve_policy_indices(names)
    refs = tuple(np.asarray(data['joint_names']).tolist())
    if len(refs) != 29 or len(set(refs)) != 29 or set(refs) != set(POLICY_JOINT_NAMES):
        raise ValueError('Expected exactly 29 named HuD04 reference joints')
    bodies = tuple(np.asarray(data['body_names']).tolist())
    if len(set(bodies)) != len(bodies) or not set(TRACKED_BODY_NAMES).issubset(bodies):
        raise ValueError('HuD04 tracking body names missing or duplicated; no G1 renaming permitted')
    q, dq = np.asarray(data['joint_pos']), np.asarray(data['joint_vel'])
    if q.ndim != 2 or q.shape[1] != 36 or dq.shape != (q.shape[0], 35) or q.shape[0] == 0:
        raise ValueError('Expected nonempty joint_pos[T,7+29] and joint_vel[T,6+29]')
    for value in (q, dq):
        if not np.issubdtype(value.dtype, np.floating) or not np.isfinite(value).all():
            raise ValueError('Joint and root state must be finite floating values')
    frames = q.shape[0]
    for key, width in [('body_pos_w', 3), ('body_quat_w', 4), ('body_lin_vel_w', 3), ('body_ang_vel_w', 3)]:
        value = np.asarray(data[key])
        if value.shape != (frames, len(bodies), width) or not np.isfinite(value).all():
            raise ValueError(f'Invalid {key} shape or finite values')
    if 'vel_cmd' in data:
        commands = np.asarray(data['vel_cmd'])
        if commands.shape != (frames, 15) or not np.isin(commands, [0., 1.]).all() or not np.all(commands.sum(axis=1) == 1):
            raise ValueError('PHP vel_cmd must be 15-class one-hot, not continuous velocity')
    fps = np.asarray(data['fps'])
    if fps.size != 1 or not np.isfinite(fps).all() or fps.item() <= 0:
        raise ValueError('fps must be a single positive finite value')
    out = {key: np.array(data[key], copy=True) for key in data.keys()}
    full_q = np.zeros((frames, 38), dtype=q.dtype)
    full_dq = np.zeros((frames, 37), dtype=dq.dtype)
    full_q[:, :7] = q[:, :7]
    full_dq[:, :6] = dq[:, :6]
    order = [refs.index(name) for name in POLICY_JOINT_NAMES]
    full_q[:, 7 + np.asarray(policy_indices)] = q[:, 7 + np.asarray(order)]
    full_dq[:, 6 + np.asarray(policy_indices)] = dq[:, 6 + np.asarray(order)]
    out['joint_pos'], out['joint_vel'] = full_q, full_dq
    out['joint_names'] = np.asarray(names, dtype=str)
    return out