"""USD composition preflight only; never a physics or training acceptance test."""


def inspect_hud04_usd(path, Usd, Tf, UsdPhysics):
    """Use Python-exposed Tf/Pcp interfaces, not Stage.GetCompositionErrors."""
    mark=Tf.Error.Mark()
    mark.SetMark()
    try:
        stage=Usd.Stage.Open(str(path))
        if stage is None:
            raise ValueError('USD stage failed to compose')
        # Include instance proxies: robot meshes/colliders are instanced and
        # ordinary Stage.Traverse() would misleadingly report zero geometry.
        prims=list(stage.Traverse(Usd.TraverseInstanceProxies()))
        errors=[str(e) for e in mark.GetErrors()]
        errors.extend(str(e) for prim in prims for e in prim.GetPrimIndex().localErrors)
        if errors:
            raise ValueError('USD composition errors: '+'; '.join(errors[:5]))
        report={
            'usd_version':list(Usd.GetVersion()),
            'layers':len(stage.GetUsedLayers()),'prims':len(prims),
            'movable_joints':sum(str(p.GetTypeName()) in ('PhysicsRevoluteJoint','PhysicsPrismaticJoint') for p in prims),
            'rigid_bodies':sum(p.HasAPI(UsdPhysics.RigidBodyAPI) for p in prims),
            'colliders':sum(p.HasAPI(UsdPhysics.CollisionAPI) for p in prims),
            'articulation_roots':sum(p.HasAPI(UsdPhysics.ArticulationRootAPI) for p in prims),
            'composition_errors':0,'physics_validated':False,
        }
        if report['layers']<4 or report['movable_joints']!=31 or report['rigid_bodies']!=42:
            raise ValueError('HuD04 USD topology incomplete: '+str(report))
        if report['colliders']==0 or report['articulation_roots']!=1:
            raise ValueError('HuD04 collision/articulation metadata incomplete: '+str(report))
        return stage,report
    finally:
        mark.Clear()