"""Two-env HuD04 integration probe, no PPO training or robot connection."""
import json
import os
from pathlib import Path
import sys
import traceback
from dataclasses import replace

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ['HUD04_VALIDATE_OUTPUT'])
INPUT=Path(os.environ['HUD04_VALIDATE_INPUT'])
sys.path.insert(0,str(ROOT))


def event(name,**fields):
    print(json.dumps({'event':name,**fields}),flush=True)


def durable_report(name,fields):
    with (OUT/name).open('x') as stream:
        json.dump(fields,stream,indent=2)
        stream.flush();os.fsync(stream.fileno())


def preserve_child_failure(phase,exc):
    failure={'phase':phase,'type':type(exc).__name__,'message':str(exc),
             'traceback':traceback.format_exc()}
    with (OUT/'child-failure.json').open('x') as stream:
        json.dump(failure,stream,indent=2);stream.flush();os.fsync(stream.fileno())
    traceback.print_exc()
    event('hud04_child_failure_preserved',phase=phase,type=type(exc).__name__)
    sys.stdout.flush();sys.stderr.flush()


def shutdown_simulator(app):
    """Use pinned Holosoma's headless shutdown, without weakening exit checks.

    Its documented workaround skips USD close_stage, disables the IsaacLab
    STOP render-loop callback, and does not wait for Replicator. This is not
    proof of native stage cleanup. A return marker is written ONLY if the
    framework helper actually returns; forced exit or exception remains failure.
    """
    from holosoma.utils.sim_utils import close_simulation_app
    from holosoma.utils.simulator_config import SimulatorType,get_simulator_type
    if get_simulator_type()!=SimulatorType.ISAACSIM:
        raise RuntimeError('Refusing a no-op non-IsaacSim shutdown path')
    strategy='pinned_holosoma_headless_workaround'
    durable_report('shutdown-started.json',{'app_close_started':True,'strategy':strategy})
    event('hud04_shutdown_started',strategy=strategy)
    close_simulation_app(app)
    durable_report('shutdown-complete.json',{'app_close_returned':True,'strategy':strategy,
                   'native_stage_cleanup_verified':False})
    event('hud04_shutdown_complete',strategy=strategy)


def main():
    import numpy as np
    import torch
    assert torch.cuda.is_available() and torch.cuda.device_count()==1
    assert float(torch.ones(4,device='cuda').sum())==4.
    event('cuda_verified',python=sys.version.split()[0],torch=torch.__version__,cuda=torch.version.cuda)
    from wbt_training.config_values.hud04_experiment import make_hud04_flat_candidate
    motion=INPUT/'motion.npz'
    with np.load(motion,allow_pickle=False) as data:
        initial_height=float(data['joint_pos'][0,2])
    cfg=make_hud04_flat_candidate(asset_root=INPUT/'asset',motion_file=motion,
                                  initial_root_height=initial_height)
    cfg=replace(cfg,training=replace(cfg.training,headless=True),
                logger=replace(cfg.logger,base_dir=str(OUT/'framework')),
                scene=replace(cfg.scene,env_spacing=4.))
    from wbt_training.utils.isaacsim_clock import use_php_isaacsim
    cfg=use_php_isaacsim(cfg)
    from holosoma.utils.sim_utils import setup_simulator_imports,setup_isaaclab_launcher
    setup_simulator_imports(cfg)
    sys.argv=[sys.argv[0]]
    app=setup_isaaclab_launcher(cfg,device='cuda:0')
    phase='usd_import'
    try:
        from pxr import Usd,Tf,UsdPhysics
        from wbt_training.hud04_usd import inspect_hud04_usd
        phase='usd_open'
        event('hud04_child_phase',phase=phase)
        usd=INPUT/'asset/usd/HU_D04_01.usd'
        phase='usd_composition_errors'
        event('hud04_child_phase',phase=phase)
        stage,stage_info=inspect_hud04_usd(usd,Usd,Tf,UsdPhysics)
        (OUT/'usd-composition.json').write_text(json.dumps(stage_info,indent=2))
        event('usd_composition_verified',**stage_info)
        phase='framework_adapter_imports'
        event('hud04_child_phase',phase=phase)
        from wbt_training.hud04_holosoma_action import HuD04PolicyPositionTargetActionTerm
        from wbt_training.hud04_holosoma_command import HuD04MotionCommand
        from holosoma.config_types.env import get_tyro_env_config
        from holosoma.utils.helpers import get_class
        event('real_framework_adapters_imported')
        phase='environment_construction'
        event('hud04_child_phase',phase=phase)
        env=get_class(cfg.env_class)(get_tyro_env_config(cfg),device='cuda:0')
        phase='environment_reset'
        event('hud04_child_phase',phase=phase)
        obs=env.reset_all()
        command=env.command_manager.get_state('motion_command')
        assert env.num_dof==31 and env.dim_actions==29
        assert command.command.shape==(2,58)
        assert command.joint_pos.shape==(2,31)
        from wbt_training.config_values.hud04_robot import HEAD_JOINT_NAMES
        heads=[env.simulator.dof_names.index(n) for n in HEAD_JOINT_NAMES]
        # Public manager iterator; inspect actual targets, not just defaults.
        action_terms=[term for _,term in env.action_manager.iter_terms()
                      if isinstance(term,HuD04PolicyPositionTargetActionTerm)]
        assert len(action_terms)==1
        action_term=action_terms[0]
        initial_head=env.simulator.dof_pos[:,heads].clone()
        expert_balancing=command._expert_balancing_active()
        assert not expert_balancing, 'Integration probe must use upstream reset delegation'
        shapes={k:list(v.shape) for k,v in obs.items()}
        resets=0
        head_max=0.
        head_square_sum=torch.zeros(2,device='cuda:0')
        head_peak=torch.zeros(2,device='cuda:0')
        joint_error_peak=0.
        head_target_peak=0.
        phase='control_steps'
        event('hud04_child_phase',phase=phase)
        with torch.inference_mode():
            for _ in range(32):
                obs,reward,done,_=env.step({'actions':torch.zeros(2,29,device='cuda:0')})
                assert all(torch.isfinite(v).all() for v in obs.values())
                assert torch.isfinite(env.simulator.dof_pos).all()
                assert torch.isfinite(reward).all()
                resets+=int(done.sum().item())
                head=env.simulator.dof_pos[:,heads]
                head_max=max(head_max,float(head.abs().max()))
                head_peak=torch.maximum(head_peak,head.abs().amax(dim=0))
                head_square_sum+=head.square().sum(dim=0)
                target=action_term._applied_position_targets[:,heads]
                assert torch.isfinite(target).all() and (target==0).all()
                head_target_peak=max(head_target_peak,float(target.abs().max()))
                joint_error_peak=max(joint_error_peak,float(
                    (env.simulator.dof_pos-command.joint_pos).abs().max()))
        result={'integration_passed':True,'physics_control_steps':33,'num_envs':2,
                'physical_joints':31,'policy_actions':29,'command_observation':58,
                'observation_shapes':shapes,'resets_during_probe':resets,
                'max_abs_head_position':head_max,'initial_root_height_from_reference':initial_height,
                'head_joint_names':list(HEAD_JOINT_NAMES),
                'initial_head_positions_rad':initial_head.tolist(),
                'head_peak_rad_by_joint':head_peak.tolist(),
                'head_rms_rad_by_joint':(head_square_sum/64).sqrt().tolist(),
                'max_abs_head_target_rad':head_target_peak,
                'max_reference_joint_error_rad':joint_error_peak,
                'reference_error_is_diagnostic_not_tracking_acceptance':True,
                'upstream_reset_delegation_verified':not expert_balancing,
                'head_hold_acceptance_defined':False,
                'trained':False,'motion_feasibility_validated':False,'checkpoint_verified':False}
        durable_report('integration-result.json',result)
        event('hud04_real_integration_passed',**result)
    except BaseException as exc:
        # IsaacSim close() may terminate Python before the outer handler runs.
        # Seal the original failure BEFORE teardown; never infer a missing report
        # is the underlying asset/runtime exception.
        preserve_child_failure(phase,exc)
        raise
    finally:
        if app is not None:
            shutdown_simulator(app)


if __name__=='__main__':
    try: main()
    except BaseException:
        traceback.print_exc()
        sys.exit(1)