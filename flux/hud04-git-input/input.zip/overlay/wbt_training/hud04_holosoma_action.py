"""Holosoma action-manager adapter; runtime integration not yet validated."""
from holosoma.managers.action.base import ActionTermBase
from wbt_training.hud04_action import HuD04PositionTargetCore


class HuD04PolicyPositionTargetActionTerm(HuD04PositionTargetCore, ActionTermBase):
    """29 policy outputs, full 31-PR-joint position targets including head hold.

    The core owns buffers and calls the simulator. ActionTermBase supplies the
    manager lifecycle. No experiment preset selects this candidate yet.
    """

    pass