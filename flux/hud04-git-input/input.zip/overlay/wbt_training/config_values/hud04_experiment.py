"""Explicit HuD04 flat integration candidate, NOT a terrain-training result.

Import-light config factory: actual Holosoma dataclasses, no simulator import.
Asset paths, a 31-joint motion, and root height must be supplied explicitly.
G1 presets and the existing training CLI are deliberately left unchanged.
"""
from dataclasses import replace
from pathlib import Path
import math
import xml.etree.ElementTree as ET
import numpy as np

from holosoma.config_types.action import ActionManagerCfg, ActionTermCfg
from holosoma.config_types.command import CommandManagerCfg, CommandTermCfg
from holosoma.config_types.randomization import RandomizationManagerCfg
from holosoma.config_values.logger import disabled as disabled_logger
from holosoma.config_values.wbt.g1.experiment import g1_29dof_wbt
from wbt_training.config_values.hud04_robot import (
    SDK_JOINT_NAMES, POLICY_JOINT_NAMES, TRACKED_BODY_NAMES, ANCHOR_BODY_NAME,
    calibration, default_position, resolve_policy_indices,
)

COMMAND_PATH = 'wbt_training.hud04_holosoma_command:HuD04MotionCommand'
ACTION_PATH = 'wbt_training.hud04_holosoma_action:HuD04PolicyPositionTargetActionTerm'


def make_hud04_flat_candidate(*, asset_root, motion_file, initial_root_height):
    """Build a deterministic small flat integration config, without executing it.

    Empty domain randomization is intentional for first integration, not a
    recommendation for final teacher training. No obstacles/heightscan, no
    checkpoint resume, no automatic artifact download or remote logging.
    """
    root = Path(asset_root).resolve()
    motion = Path(motion_file).resolve()
    urdf = root / 'urdf/HU_D04_01.urdf'
    usd = root / 'usd/HU_D04_01.usd'
    for path in (urdf, usd, motion):
        if not path.is_file():
            raise ValueError(f'Required local input missing: {path}')
    if not math.isfinite(initial_root_height) or initial_root_height <= 0:
        raise ValueError('Explicit positive finite root height required')
    model = ET.parse(urdf).getroot()
    joints = {j.get('name'): j for j in model.findall('joint') if j.get('type') != 'fixed'}
    resolve_policy_indices(tuple(joints))
    bodies = [link.get('name') for link in model.findall('link')]
    if len(set(bodies)) != len(bodies) or not bodies or bodies[0] != 'base_link' or not set(TRACKED_BODY_NAMES).issubset(bodies):
        raise ValueError('URDF must have unique HuD04 bodies with base_link first')
    with np.load(motion, allow_pickle=False) as data:
        resolve_policy_indices(tuple(data['joint_names'].tolist()))
        motion_bodies = data['body_names'].tolist()
        if len(set(motion_bodies)) != len(motion_bodies) or not set(bodies).issubset(motion_bodies):
            raise ValueError('Motion is missing physical URDF body states')
        q, dq = data['joint_pos'], data['joint_vel']
        if q.ndim != 2 or q.shape[0] == 0 or q.shape[1] != 38 or dq.shape != (q.shape[0],37):
            raise ValueError('Expected full 31-joint reference state arrays')
        if not np.isfinite(q).all() or not np.isfinite(dq).all():
            raise ValueError('Nonfinite reference state')
        head_columns = [data['joint_names'].tolist().index(n) for n in ('head_yaw_joint','head_pitch_joint')]
        if not np.all(q[:,7+np.asarray(head_columns)] == 0) or not np.all(dq[:,6+np.asarray(head_columns)] == 0):
            raise ValueError('Head-hold candidate requires zero reference head states')
        for key, width in [('body_pos_w',3),('body_quat_w',4),('body_lin_vel_w',3),('body_ang_vel_w',3)]:
            values=data[key]
            if values.shape != (q.shape[0],len(motion_bodies),width) or not np.isfinite(values).all():
                raise ValueError(f'Invalid body-state array: {key}')
        fps=np.asarray(data['fps'])
        if fps.size != 1 or not np.isfinite(fps).all() or abs(float(fps.item())-50.) > 1e-6:
            raise ValueError('Flat candidate requires 50 Hz reference matching 200/4 control')
        commands = data['vel_cmd']
        if commands.shape != (q.shape[0],15) or not np.isin(commands,[0,1]).all() or not np.all(commands.sum(axis=1)==1):
            raise ValueError('Expected PHP 15-class one-hot vel_cmd')
    limits = [joints[n].find('limit') for n in SDK_JOINT_NAMES]
    lower = [float(x.get('lower')) for x in limits]
    upper = [float(x.get('upper')) for x in limits]
    if any(not math.isfinite(l) or not math.isfinite(u) or not l <= default_position(n) <= u
           for n, l, u in zip(SDK_JOINT_NAMES, lower, upper)):
        raise ValueError('Invalid joint limits or default position outside limits')
    base = g1_29dof_wbt
    robot = replace(base.robot,
        num_bodies=len(bodies), dof_obs_size=29, actions_dim=29,
        policy_obs_dim=-1, critic_obs_dim=-1, algo_obs_dim_dict={},
        key_bodies=['left_ankle_roll_link', 'right_ankle_roll_link'],
        foot_body_name='ankle_roll_link', foot_height_name='ankle_roll_link', torso_name=ANCHOR_BODY_NAME,
        dof_names=list(SDK_JOINT_NAMES), body_names=bodies,
        upper_dof_names=list(SDK_JOINT_NAMES[12:]),
        upper_left_arm_dof_names=list(POLICY_JOINT_NAMES[15:22]),
        upper_right_arm_dof_names=list(POLICY_JOINT_NAMES[22:29]),
        lower_dof_names=list(POLICY_JOINT_NAMES[:12]),
        left_ankle_dof_names=list(POLICY_JOINT_NAMES[4:6]),
        right_ankle_dof_names=list(POLICY_JOINT_NAMES[10:12]),
        knee_dof_names=[n for n in SDK_JOINT_NAMES if 'knee' in n],
        hips_dof_names=[n for n in SDK_JOINT_NAMES if 'hip_' in n],
        dof_pos_lower_limit_list=lower, dof_pos_upper_limit_list=upper,
        dof_vel_limit_list=[calibration(n)[3] for n in SDK_JOINT_NAMES],
        dof_effort_limit_list=[calibration(n)[2] for n in SDK_JOINT_NAMES],
        dof_armature_list=[calibration(n)[4] for n in SDK_JOINT_NAMES],
        dof_joint_friction_list=[0.] * 31,
        terminate_after_contacts_on=[], penalize_contacts_on=[], randomize_link_body_names=['base_link'],
        waist_dof_names=list(POLICY_JOINT_NAMES[12:15]),
        arm_dof_names=list(POLICY_JOINT_NAMES[15:]),
        left_arm_dof_names=list(POLICY_JOINT_NAMES[15:22]),
        right_arm_dof_names=list(POLICY_JOINT_NAMES[22:29]),
        symmetry_joint_names=None, flip_sign_joint_names=None,
        init_state=replace(base.robot.init_state, pos=[0.,0.,initial_root_height],
            default_joint_angles={n:default_position(n) for n in SDK_JOINT_NAMES}),
        control=replace(base.robot.control, control_mode='implicit_position_target',
            stiffness={n.removesuffix('_joint'):calibration(n)[0] for n in SDK_JOINT_NAMES},
            damping={n.removesuffix('_joint'):calibration(n)[1] for n in SDK_JOINT_NAMES},
            action_scale=.25, action_scales_by_effort_limit_over_p_gain=True,
            implicit_actuator_builder='wbt_training.config_values.hud04_robot:build_hud04_implicit_actuators'),
        asset=replace(base.robot.asset, asset_root=str(root), urdf_file=str(urdf),
            usd_file=str(usd), xml_file='', robot_type='hud04', collapse_fixed_joints=False,
            mesh_root=str(root / 'meshes')))
    groups = {}
    for name, group in base.observation.groups.items():
        terms = dict(group.terms)
        terms['dof_pos'] = replace(terms['dof_pos'], func='wbt_training.hud04_state:policy_dof_pos')
        terms['dof_vel'] = replace(terms['dof_vel'], func='wbt_training.hud04_state:policy_dof_vel')
        groups[name] = replace(group, terms=terms, enable_noise=False)
    old_motion = base.command.setup_terms['motion_command'].params['motion_config']
    motion_cfg = replace(old_motion, motion_file=str(motion), motion_dir='',
        body_names_to_track=list(TRACKED_BODY_NAMES), body_name_ref=[ANCHOR_BODY_NAME],
        enable_default_pose_prepend=False, enable_default_pose_append=False,
        noise_to_initial_pose=replace(old_motion.noise_to_initial_pose, overall_noise_scale=0.))
    command = CommandManagerCfg(
        setup_terms={'motion_command':CommandTermCfg(func=COMMAND_PATH, params={'motion_config':motion_cfg})},
        reset_terms={'motion_command':CommandTermCfg(func=COMMAND_PATH)},
        step_terms={'motion_command':CommandTermCfg(func=COMMAND_PATH)})
    terminations = dict(base.termination.terms)
    bad = terminations['bad_tracking']
    terminations['bad_tracking'] = replace(bad, params={**bad.params,
        'body_names_to_track':list(TRACKED_BODY_NAMES),
        'bad_motion_body_pos_body_names':['left_ankle_roll_link','right_ankle_roll_link','left_wrist_roll_link','right_wrist_roll_link']})
    rewards = dict(base.reward.terms)
    contact = rewards['undesired_contacts']
    rewards['undesired_contacts'] = replace(contact, params={**contact.params,
        'undesired_contacts_body_names':'^(?!contact_foot_.*$)(?!left_hand_(?:contact|manip)$)(?!right_hand_(?:contact|manip)$)(?!left_ankle_roll_link$)(?!right_ankle_roll_link$)(?!left_wrist_roll_link$)(?!right_wrist_roll_link$).+$'})
    return replace(base, robot=robot, command=command,
        env_class='wbt_training.hud04_holosoma_env.HuD04WholeBodyTrackingManager',
        nightly=None,
        simulator=replace(base.simulator, config=replace(base.simulator.config,
            bridge=replace(base.simulator.config.bridge, enabled=False),
            virtual_gantry=replace(base.simulator.config.virtual_gantry,
                attachment_body_names=['base_link'], enabled=False))),
        action=ActionManagerCfg(terms={'joint_control':ActionTermCfg(func=ACTION_PATH)}),
        observation=replace(base.observation, groups=groups),
        termination=replace(base.termination, terms=terminations),
        reward=replace(base.reward, terms=rewards),
        randomization=RandomizationManagerCfg(), logger=disabled_logger,
        training=replace(base.training, name='hud04_flat_integration_CANDIDATE',
            project='HuD04_WBT', num_envs=2, checkpoint=None, registry_name=None,
            preprocess_hook=None, export_onnx=False),
        algo=replace(base.algo, config=replace(base.algo.config,
            num_learning_iterations=2, init_at_random_ep_len=False)))