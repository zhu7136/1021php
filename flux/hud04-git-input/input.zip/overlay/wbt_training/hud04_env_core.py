"""HuD04-only asset layout: 31 physical PR joints, 29 policy actions.

Mirrors BaseTask._load_assets bookkeeping while replacing its all-DOFs-actuated
dimension assumption with the strict HuD04 named-joint contract. Does not change
the common BaseTask or use temporary action dimensions.
"""
import torch
from wbt_training.config_values.hud04_robot import resolve_policy_indices


class HuD04AssetLayoutMixin:
    def _load_assets(self):
        self.simulator.load_assets()
        self.num_dof = self.simulator.num_dof
        self.num_bodies = self.simulator.num_bodies
        self.dof_names = self.simulator.dof_names
        self.body_names = self.simulator.body_names
        if self.num_dof != 31 or self.dim_actions != 29:
            raise ValueError('HuD04 requires 31 physical joints and 29 policy actions')
        resolve_policy_indices(tuple(self.dof_names))
        if tuple(self.dof_names) != tuple(self.robot_config.dof_names):
            raise ValueError('Simulator/configured joint orders differ')
        if (len(self.body_names) != self.num_bodies or
                len(set(self.body_names)) != self.num_bodies or
                tuple(self.body_names) != tuple(self.robot_config.body_names) or
                not self.body_names or self.body_names[0] != 'base_link'):
            raise ValueError('Simulator/configured physical bodies differ')
        self.num_dofs = len(self.dof_names)
        init = self.robot_config.init_state
        values = init.pos + init.rot + init.lin_vel + init.ang_vel
        if len(values) != 13:
            raise ValueError('Expected 13-element floating base state')
        self.base_init_state = torch.tensor(values, device=self.device, dtype=torch.float32)
        if not torch.isfinite(self.base_init_state).all():
            raise ValueError('Nonfinite floating base state')