"""HuD04 joint-state layout and observation/reset helpers (CPU-testable).

These helpers do not retarget motions, write simulator state, or certify that
a reference trajectory is dynamically feasible. Head motion is held at zero.
"""
from __future__ import annotations

import torch
from wbt_training.config_values.hud04_robot import (
    HEAD_JOINT_NAMES, POLICY_JOINT_NAMES, resolve_policy_indices,
    TRACKED_BODY_NAMES, ANCHOR_BODY_NAME,
)


class HuD04StateLayout:
    def __init__(self, physical_names):
        self.physical_names = tuple(physical_names)
        self.policy_indices = resolve_policy_indices(self.physical_names)
        self.head_indices = tuple(self.physical_names.index(n) for n in HEAD_JOINT_NAMES)

    @staticmethod
    def _check(tensor, width):
        if not isinstance(tensor, torch.Tensor) or tensor.ndim < 2 or tensor.shape[-1] != width:
            raise ValueError(f"Expected a batched tensor with last dimension {width}")
        if not tensor.is_floating_point() or not torch.isfinite(tensor).all():
            raise ValueError("State tensors must be finite floating-point values")

    def policy_state(self, physical_state):
        self._check(physical_state, 31)
        return physical_state[..., list(self.policy_indices)]

    def reset_state(self, joint_pos, joint_vel, reference_names=POLICY_JOINT_NAMES):
        """Reorder 29 reference joints, append head q=dq=0; leave inputs untouched.

        Returns joint states only: caller must supply root state, apply any
        permitted noise/limits, and write state through the simulator API.
        """
        names = tuple(reference_names)
        if len(names) != 29 or len(set(names)) != 29 or set(names) != set(POLICY_JOINT_NAMES):
            raise ValueError("Reference must name exactly the 29 HuD04 policy joints")
        self._check(joint_pos, 29)
        self._check(joint_vel, 29)
        if joint_pos.shape != joint_vel.shape or joint_pos.device != joint_vel.device or joint_pos.dtype != joint_vel.dtype:
            raise ValueError("Position and velocity tensors must have matching shape/device/dtype")
        order = [names.index(n) for n in POLICY_JOINT_NAMES]
        shape = (*joint_pos.shape[:-1], 31)
        full_pos = joint_pos.new_zeros(shape)
        full_vel = joint_vel.new_zeros(shape)
        full_pos[..., list(self.policy_indices)] = joint_pos[..., order]
        full_vel[..., list(self.policy_indices)] = joint_vel[..., order]
        return full_pos, full_vel

    def enforce_head_hold(self, joint_pos, joint_vel):
        """Apply AFTER reset noise/clamping; return copies without modifying inputs."""
        self._check(joint_pos, 31)
        self._check(joint_vel, 31)
        if joint_pos.shape != joint_vel.shape:
            raise ValueError("Position/velocity reset shapes must match")
        pos, vel = joint_pos.clone(), joint_vel.clone()
        pos[..., list(self.head_indices)] = 0.
        vel[..., list(self.head_indices)] = 0.
        return pos, vel


def _layout(env):
    names = tuple(env.robot_config.dof_names)
    # Fail rather than assume the simulator uses the config's physical order.
    if tuple(env.simulator.dof_names) != names:
        raise ValueError("Simulator/config physical joint orders differ")
    if getattr(env, "state_estimator", None) is not None:
        raise NotImplementedError("State-estimator observation integration is not validated")
    return HuD04StateLayout(names)


def policy_dof_pos(env):
    """Unscaled 29-joint offsets, like upstream WBT dof_pos but head-excluded."""
    layout = _layout(env)
    positions = env.simulator.dof_pos
    defaults = env.default_dof_pos
    layout._check(positions, 31)
    if defaults.ndim not in (1, 2) or defaults.shape[-1] != 31:
        raise ValueError("Expected 31-joint default positions")
    if not torch.isfinite(defaults).all():
        raise ValueError("Default positions must be finite")
    return layout.policy_state(positions - defaults)


def policy_dof_vel(env):
    """Unscaled 29-joint velocities; scaling belongs to the observation config."""
    return _layout(env).policy_state(env.simulator.dof_vel)


def validate_tracking_bodies(simulator_names, motion_names):
    """Exact HuD04 names only; no automatic pelvis/torso G1 relabeling."""
    sim, motion = tuple(simulator_names), tuple(motion_names)
    if len(set(sim)) != len(sim) or len(set(motion)) != len(motion):
        raise ValueError("Body names must be unique")
    missing_sim = sorted(set(TRACKED_BODY_NAMES) - set(sim))
    missing_motion = sorted(set(TRACKED_BODY_NAMES) - set(motion))
    if missing_sim or missing_motion:
        raise ValueError(f"Missing HuD04 bodies: simulator={missing_sim}, reference={missing_motion}")
    return {"simulator_indices": tuple(sim.index(n) for n in TRACKED_BODY_NAMES),
            "motion_indices": tuple(motion.index(n) for n in TRACKED_BODY_NAMES),
            "anchor_body": ANCHOR_BODY_NAME}