"""Real framework adapter; full simulator execution remains unvalidated."""
from wbt_training.hud04_command_core import HuD04CommandMixin
from wbt_training.config_values.motion_command import PhpMotionCommand


class HuD04MotionCommand(HuD04CommandMixin, PhpMotionCommand):
    """31 physical reference joints, 58 policy reference values, head reset hold."""

    pass